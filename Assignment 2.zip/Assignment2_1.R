rm(list = ls())
library("cluster")
library("ISLR")
data("USArrests")
attach(USArrests)
names(USArrests)
summary(USArrests)
dim(USArrests)

# Part a
# States covered
states <- row.names(USArrests)
states # All 50 states

# hierarchical clustering
d <- dist(USArrests)
hc.complete =hclust (dist(USArrests), method ="complete")

# plot the dendrogram
x11()
plot(hc.complete ,main =" Complete Linkage ", xlab="", sub ="",cex =.9)

# Part b
hc.cluster <- cutree(hc.complete , 3)
table(hc.cluster, states)
si <- silhouette(cutree(hc.complete, k = 3), dist = d)
summary(si)
x11()
plot(si)

# Part c
xsc=scale (USArrests)
hc.sd =hclust (dist(xsc), method ="complete")
summary(xsc)
x11()
plot(hclust (dist(xsc), method ="complete"), main =" Hierarchical Clustering with Scaled Features ")
     
# Part d
table(hc.cluster, cutree(hc.sd,3))
