rm(list = ls())
library(ISLR)

setwd("C:/Users/jadha/OneDrive/Documents/SPRING2018/SDM2/RFILES")

# Part a
#reading csv and loading
gene_sample = read.csv(file = "Ch10Ex11.csv", header = F)
attach(gene_sample)

# study of variables
summary(gene_sample)
names(gene_sample)
dim(gene_sample)

# Part b
# Hierarchical clustering 
# Dissimilarity = 1 - Correlation
# Here the R code that creates a distance matrix from 1-Correlation as the dissimilarity index
# Note the as.dist function is used here to assign the correlation values to be "distances".  (In some cases, you may want to use the dist function to compute distances using a variety of distance metrics instead.) 
d <- 1 - cor(gene_sample)

# Linkage : complete
hc.complete =hclust (as.dist(d), method ="complete")
# plot the dendrogram
x11()
plot(hc.complete ,main =" Complete Linkage ", xlab="", sub ="",cex =.9)

# Linkage : average
hc.average =hclust (as.dist(d), method = "average")
# plot the dendrogram
x11()
plot(hc.average ,main =" Average Linkage ", xlab="", sub ="",cex =.9)

# Linkage : single
hc.single =hclust (as.dist(d), method = "single")
# plot the dendrogram
x11()
plot(hc.single ,main =" Single Linkage ", xlab="", sub ="",cex =.9)

# Part c
# Apply PCA
gene_sample = t(gene_sample)
max(apply(gene_sample,2, var))

pr.out =prcomp(gene_sample)
pr.out
head(pr.out$rotation)
names(pr.out)
pr.out$sdev
# So we can see that these are all the uncorrelated Principal components. And they are always decreasing. The largest one is 2.54 and 
#the smallest one is 0.709
#Then the rotations are called loadings
pr.var = pr.out$sdev^2
#To compute the proportion of variance explained by each principal component,
#we simply divide the variance explained by each principal component
#by the total variance explained by all principal components
pve=pr.var/sum(pr.var )
pve
plot(pve , xlab=" Principal Component ", ylab=" Proportion of Variance Explained ", ylim=c(0,1) , xlim=c(1,10),type='b')

total.load <- apply(pr.out$rotation, 1, sum)
index <- order(abs(total.load), decreasing = TRUE)
index[1:15]
