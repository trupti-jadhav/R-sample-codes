rm(list = ls())

library("cluster")

# Part a
# Generate a simulated dataset
set.seed (121)
x=matrix (rnorm (20 * 3 * 50, mean = 0, sd = 0.001) , ncol =50)
x[1:20 ,1]<- x[1:20 ,1]+3
x[21:40 ,2] <- x[21:40 ,2] -4
x[21:40, 1] <- x[21:40, 1]+1
x[41:60, 1] <- x[41:60, 1]-2

true.labels <- c(rep(1, 20), rep(2, 20), rep(3, 20))

# part b

pr.out =prcomp (x)
names(pr.out)
pr.out$sdev
pr.out$rotation
pr.out$center
pr.out$scale
dim(pr.out$x)
?prcomp()
?biplot
biplot (pr.out , scale =0)
plot(pr.out$x[, 1:2],col=c("red", "green", "blue"), pch = 12)

# Part c
# Kmean with k=3
km <- kmeans(x,3)
table(km$cluster, true.labels)

# Part d
# Kmean with k=2
km <- kmeans(x,2)
table(km$cluster, true.labels)

# Part e
# Kmean with k=4
km <- kmeans(x,4)
table(km$cluster, true.labels)

# Part f
# Kmean with k=3 and 1st 2 PC
km <- kmeans(pr.out$x[,1:2],3)
table(km$cluster, true.labels)

# Part g
# Kmean with k=3 and scaling
km <- kmeans(scale(x),3)
table(km$cluster, true.labels)
