rm(list = ls())
graphics.off()

#install.packages("magrittr")
library(magrittr)
#install.packages("dplyr")
library("arules")
library("dplyr")
library("MASS")
data(Boston)
attach(Boston)
summary(Boston)
names(Boston)
?Boston

##########################################################################

# Histograms
#image(Boston, pch = 20)x11()
par(mfrow = c(4,4))
hist(crim)
hist(zn)
hist(indus)
hist(chas)
hist(nox)
hist(rm)
hist(age)
hist(dis)
hist(rad)
hist(tax)
hist(ptratio)
hist(black)
hist(lstat)
hist(medv)

?transactionInfo



# Convert the ordinal data to factor

#Boston$chas = factor(chas,labels = c("river","noriver"))
#Boston$rad = factor(rad)
#Boston$black = cut(Boston$black,breaks = 4,labels = c(">31.5%","18.5-31.5%","8-18.5","<8%"))
#a = as.character(chas:rad:black)
Boston[["crim"]] = ordered(cut(Boston[["crim"]], c(0, 10, 40, 100)), labels = c("LOW", "MEDIUM", "HIGH"))
Boston[["age"]] = ordered(cut(Boston[["age"]], c(0, 20, 40, 60, 80, 100)), labels = c("Very new", "new", "average", "old", "very old"))
Boston[["dis"]] = ordered(cut(Boston[["dis"]], c(2, 6, 8, 12)), labels = c("short", "average", "long"))
Boston[["chas"]] = factor(chas,labels = c("river","noriver"))
Boston[["ptratio"]] = ordered(cut(Boston[["ptratio"]], c(12, 15, 18,22)), labels = c("Low", "Medium", "High"))
Boston[["tax"]] = ordered(cut(Boston[["tax"]], c(0, 300, 500, 800)), labels = c("Low", "Moderate", "High"))
Boston[["rm"]] = ordered(cut(Boston[["rm"]], c(3, 5, 7, 9)), labels = c("Low", "Moderate", "High"))
Boston[["medv"]] = ordered(cut(Boston[["medv"]], c(0, 15, 25, 50)), labels = c("Low", "Medium", "High"))
Boston[["lstat"]] = ordered(cut(Boston[["lstat"]], c(0, 10, 20, 40)), labels = c("Low", "Medium", "High"))

Boston[["zn"]] = NULL
Boston[["nox"]] = NULL
Boston[["indus"]] = NULL
Boston[["black"]] = NULL
Boston[["rad"]]= NULL

#D = function(x) cut(x, breaks =4, labels = c("LOWER","LOW","HIGH","HIGHER"))
#Boston = select(Boston,-one_of(a)) %>%
  
#  mutate_at(funs(D))  %>%
#  bind_cols(select(Boston, one_of(a)))
#Boston = as(Boston,"transactions")
#Boston

#Convert to a binary incidence matrix
b = as(Boston, "transactions")
summary(b)

# PART b
x11()
itemFrequencyPlot(b, support = 0.05, cex.names = 0.8)

# Apply the apriori algorithm
rules  <- apriori(b, parameter = list(support = 0.01, confidence = 0.6))
summary(rules)

# PART c


rules<-apriori(b, parameter=list(support=0.01,confidence=0.6),appearance = list(lhs=c("dis=short"),default="rhs"))

rules_LowCrime <- subset(rules, subset = rhs %in% "crim=LOW" & lift>1)
summary(rules_LowCrime)
inspect(head(sort(rules_LowCrime,by="confidence"),n=10))

#Part d
rules<-apriori(b, parameter=list(support=0.01,confidence=0.6))
rules_LowPTRatio <- subset(rules, subset = rhs %in% "ptratio=Low" & lift>1)
summary(rules_LowPTRatio)
inspect(head(sort(rules_LowPTRatio,by="confidence"),n=10))
