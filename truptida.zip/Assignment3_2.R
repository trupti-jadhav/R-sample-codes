
#install.packages("MMST")
rm(list = ls())
library("cluster")
library("ISLR")
library(ISLR)
load("C://Users//jadha//OneDrive//Documents//SPRING2018//SDM2//RFILES//primate.scapulae.rda")
attach(primate.scapulae)
summary(primate.scapulae)
names(primate.scapulae)
dim(primate.scapulae)
attributes= row.names(primate.scapulae)
set.seed(589)

# Part A : hierarchical clustering
primate.scapulae = data.frame(primate.scapulae)
class = primate.scapulae$classdigit
#primate.scapulae = primate.scapulae[-c("10","11")]
primate.scapulae$classdigit = NULL
primate.scapulae$class = NULL
#primate.scapulae  =  na.omit(primate.scapulae)
#primate.scapulae$class = as.numeric(primate.scapulae$class)
#primate.scapulae$classdigit = as.numeric(primate.scapulae$classdigit)
primate.scapulae$gamma[is.na(primate.scapulae$gamma)] = mean(primate.scapulae$gamma, na.rm = T)
d = dist(primate.scapulae)

# Linkage : complete
hc.complete =hclust (d, method ="complete")
# plot the dendrogram
x11()
plot(hc.complete ,main =" Complete Linkage ", xlab="", sub ="",cex =.9)
# Decide on grouping
hc.cluster = cutree(hc.complete , 5)
si <- silhouette(cutree(hc.complete, k = 5), dist = d)
t_complete = table(hc.cluster, attributes)
t_complete
plot(si)
table(hc.cluster, class)
misclassification_rate = (29/105)*100


# Linkage : average
hc.average =hclust (as.dist(d), method = "average")
# plot the dendrogram
x11()
plot(hc.average ,main =" Average Linkage ", xlab="", sub ="",cex =.9)
# Decide on grouping
hc.cluster <- cutree(hc.average , 6)
si <- silhouette(cutree(hc.average, k = 6), dist = d)
t_average = table(hc.cluster, attributes)
t_average
plot(si)
table(hc.cluster, class)
misclassification_rate = (29/105)*100

# Linkage : single
hc.single =hclust (as.dist(d), method = "single")
# plot the dendrogram
x11()
plot(hc.single ,main =" Single Linkage ", xlab="", sub ="",cex =.9)
# Decide on grouping
hc.cluster = cutree(hc.single , 3)
si <- silhouette(cutree(hc.single, k = 3), dist = d)
t_single = table(hc.cluster, attributes)
t_single
plot(si)
table(hc.cluster, class)
misclassification_rate = (14+15+15/105)*100

# Part B : K-means
fit <- prcomp(primate.scapulae)
x11()
screeplot(fit,type="lines") # scree plot 
s = c()
km = kmeans(primate.scapulae,5)
values = unique(class) # 1 2 3 4 5
for(i in values){
s1 = sum(class == i) # 14 40 16 20 15
s = c(s, s1)
}
s
table(km$cluster, class)
misclassification_rate = ((16+13+15+1+1)*100)/105