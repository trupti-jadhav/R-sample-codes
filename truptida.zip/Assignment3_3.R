rm(list = ls())
library(ElemStatLearn)
library(kohonen)
library(phyclust)
data(nci)
nci = data.frame(nci)
summary(nci)
names(nci)
?nci
?scale
nci.scaled = scale(nci)


set.seed(67231)

# Number of clusters: 2 (k = 2)

carrier_rand_index = c()
carrier_adjustedrand_index = c()

for(i in c(20,12,8,5)){
km = kmeans(nci.scaled,2)
nci.som = supersom(data = nci.scaled, grid = somgrid(2,1,"hexagonal"), radius = i)
similar = RRand(km$cluster, nci.som$unit.classif)
similar
similar$Rand      # Rand gives us the percentage of similarity
similar$adjRand
carrier_rand_index = c(carrier_rand_index, similar$Rand)
carrier_adjustedrand_index = c(carrier_adjustedrand_index, similar$adjRand)
}
carrier_rand_index
carrier_adjustedrand_index
x11()
par(mfrow = c(2,1))
plot(carrier_rand_index, type = "b")
plot(carrier_adjustedrand_index, type = "b")
table(km$cluster, nci.som$unit.classif)


# Number of clusters: 5 (k = 5)


carrier_rand_index = c()
carrier_adjustedrand_index = c()

for(i in c(20,12,8,5)){
  km = kmeans(nci.scaled,5)
  nci.som = supersom(data = nci.scaled, grid = somgrid(5,1,"hexagonal"), radius = i)
  similar = RRand(km$cluster, nci.som$unit.classif)
  similar
  similar$Rand      # Rand gives us the percentage of similarity
  similar$adjRand
  carrier_rand_index = c(carrier_rand_index, similar$Rand)
  carrier_adjustedrand_index = c(carrier_adjustedrand_index, similar$adjRand)
}
carrier_rand_index
carrier_adjustedrand_index
x11()
par(mfrow = c(2,1))
plot(carrier_rand_index, type = "b")
plot(carrier_adjustedrand_index, type = "b")
table(km$cluster, nci.som$unit.classif)

# Number of clusters: 10 (k = 10)


carrier_rand_index = c()
carrier_adjustedrand_index = c()

for(i in c(20,12,8,5)){
  km = kmeans(nci.scaled,10)
  nci.som = supersom(data = nci.scaled, grid = somgrid(5,2,"hexagonal"), radius = i)
  similar = RRand(km$cluster, nci.som$unit.classif)
  similar
  similar$Rand      # Rand gives us the percentage of similarity
  similar$adjRand
  carrier_rand_index = c(carrier_rand_index, similar$Rand)
  carrier_adjustedrand_index = c(carrier_adjustedrand_index, similar$adjRand)
}
carrier_rand_index
carrier_adjustedrand_index
x11()
par(mfrow = c(2,1))
plot(carrier_rand_index, type = "b")
plot(carrier_adjustedrand_index, type = "b")
table(km$cluster, nci.som$unit.classif)

# Number of clusters: 20 (k = 20)

carrier_rand_index = c()
carrier_adjustedrand_index = c()

for(i in c(20,12,8,5)){
  km = kmeans(nci.scaled,20)
  nci.som = supersom(data = nci.scaled, grid = somgrid(5,4,"hexagonal"), radius = i)
  similar = RRand(km$cluster, nci.som$unit.classif)
  similar
  similar$Rand      # Rand gives us the percentage of similarity
  similar$adjRand
  carrier_rand_index = c(carrier_rand_index, similar$Rand)
  carrier_adjustedrand_index = c(carrier_adjustedrand_index, similar$adjRand)
}
carrier_rand_index
carrier_adjustedrand_index
x11()
par(mfrow = c(2,1))
plot(carrier_rand_index, type = "b")
plot(carrier_adjustedrand_index, type = "b")
table(km$cluster, nci.som$unit.classif)
