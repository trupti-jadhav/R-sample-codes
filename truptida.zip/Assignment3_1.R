#install.packages("MMST")
rm(list = ls())
library(ISLR)
load("C://Users//jadha//OneDrive//Documents//SPRING2018//SDM2//RFILES//SwissBankNotes.rdata")
attach(SwissBankNotes)
summary(SwissBankNotes)
names(SwissBankNotes)
dim(SwissBankNotes)
records= row.names(SwissBankNotes)
set.seed(123)

# Part A : Diagnostic test
SwissBankNotes = data.frame(SwissBankNotes)
SwissBankNotes = na.omit(SwissBankNotes)
par(mfrow = c(2,3))
boxplot(SwissBankNotes$length)
boxplot(SwissBankNotes$height.left)
boxplot(SwissBankNotes$height.right)
boxplot(SwissBankNotes$inner.lower)
boxplot(SwissBankNotes$inner.upper)
boxplot(SwissBankNotes$diagonal)

par(mfrow = c(2,3))
hist(SwissBankNotes$length, main ="length")
hist(SwissBankNotes$height.left, main = "height.left")
hist(SwissBankNotes$height.right, main = "height.right")
hist(SwissBankNotes$inner.lower, main = "inner.lower")
hist(SwissBankNotes$inner.upper, main = "inner.upper")
hist(SwissBankNotes$diagonal, main = "diagonal")

genuine = SwissBankNotes[1:100,]
counterfeit = SwissBankNotes[101:200,]

# Part B : Compute Principal Component Analysis

# genuine
pr.out =prcomp (genuine)
names(pr.out)
pr.out$sdev
pr.out$rotation
pr.out$center
pr.out$scale
dim(pr.out$x)
?prcomp()
?biplot
plot(pr.out)
x11()
biplot (pr.out , scale =0, main = "hhh")

# counterfeit
pr.out =prcomp (counterfeit)
names(pr.out)
pr.out$sdev
pr.out$rotation
pr.out$center
pr.out$scale
dim(pr.out$x)
?prcomp()
?biplot
plot(pr.out)
x11()
biplot (pr.out , scale =0)

# SwissBankNotes
pr.out =prcomp (SwissBankNotes)
names(pr.out)
pr.out$sdev
pr.out$rotation
pr.out$center
pr.out$scale
dim(pr.out$x)
?prcomp()
?biplot
plot(pr.out)
x11()
biplot (pr.out , scale =0, main = "whole")